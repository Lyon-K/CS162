#include <iostream>
#include <fstream>
#include <string.h>
#include "menu.h"

using namespace std;

Menu::Menu(){
	this->num_pizzas = 0;
	this->pizzas_cap = 0;
	this->pizzas = NULL;
}


Menu::~Menu(){
	delete[] this->pizzas;
}


Menu::Menu(const Menu& old_obj){
    this->num_pizzas = old_obj.num_pizzas;
}


Menu& Menu::operator=(const Menu& old_obj){
    this->num_pizzas = old_obj.num_pizzas;
}


int Menu::get_num_pizzas(){
	return this->num_pizzas;
}


Pizza* Menu::get_pizzas(){
	if(this->pizzas != NULL)
		return this->pizzas;
	cout << "INVALID GET PIZZAS\n";
}


// int Menu::get_pizzas_cap(){
//  return this->pizzas_cap;
// }


void Menu::set_num_pizzas(int num){
	if(num < 0){
		cout << "NUMBER OF PIZZA IS INVALID\n";
		return;
	}
	while(this->pizzas_cap < num){
		cout << "RESIZED PIZZAS CAPACITY\n";
		set_pizzas_cap(num*2);
	}
	this->num_pizzas = num;
}


void Menu::set_pizzas_cap(int cap){
	Pizza* temp = new Pizza[cap];
	for(int i = 0; i < this->num_pizzas; ++i){
		temp[i] = this->pizzas[i];
	}
	delete[] this->pizzas;
	this->pizzas = temp; //temp address gets deleted after this function???
	this->pizzas_cap = cap;
}


Menu Menu::search_pizza_by_cost(int upper_bound){

}


//Menu search_pizza_by_cost(int upper_bound, string size);

Menu Menu::search_pizza_by_ingredients_to_include(string* ingredients, int num_ingredients){

}


Menu Menu::search_pizza_by_ingredients_to_exclude(string* ingredients, int num_ingredients){

}


void Menu::add_to_menu(Pizza pizza_to_add){
	if(this->num_pizzas == 0){
		cout << "Please insert the number of pizzas first\n";
		return;
	}
	if(this->pizzas_cap == 0)
		pizzas = new Pizza[this->num_pizzas];
	// if(this->num_pizzas == this->pizzas_cap)

}


void Menu::remove_from_menu(int index_of_pizza_on_menu){
	if(index_of_pizza_on_menu > num_pizzas || index_of_pizza_on_menu < 0){
		cout << "Unable to remove non-existant pizza\n";
		return;
	}
	--this->num_pizzas;
	cout << "Removed " << this->pizzas[index_of_pizza_on_menu].get_name() << endl;
	for(int i = index_of_pizza_on_menu; i < this->num_pizzas; ++i){
		this->pizzas[i] = this->pizzas[i+1];
	}
}

