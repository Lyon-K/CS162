#include <iostream>
#include <fstream>
#include "restaurant.h"
using namespace std;


//reads from files to correctly populate menu, employees, hours, etc.
Restaurant::Restaurant(){
    cout << "RESTAURANT DEFAULT CONSTRUCTOR CALLED\n";
    this->employees = NULL;
    this->week = NULL;
    this->name = "";
    this->phone = "";
    this->address = "";
}

Restaurant::~Restaurant(){
    cout << "RESTAURANT DESTRUCTOR CALLED\n";
    if(this->employees != NULL)
        delete this->employees;
    if(this->week != NULL)
        delete this->week;
}


Restaurant::Restaurant(const Restaurant& old_obj){
    cout << "RESTAURANT COPY CONSTRUCTOR CALLED\n";
    this->menu = old_obj.menu;
    // this->employees = old_obj.employees;
    this->employees = old_obj.employees;
    // this->week = new week;
    this->week = old_obj.week;
    this->name = old_obj.name;
    this->phone = old_obj.phone;
    this->address = old_obj.address;
}


Restaurant& Restaurant::operator=(const Restaurant old_obj){
    cout << "RESTAURANT AOO CALLED\n";
    if(this != &old_obj){
        cout << "RESTAURANT AOO ASSIGNMENT CALLED";
        this->menu = old_obj.menu;
        // if(this->employees == NULL)
        //     this->employees = new employees;
        this->employees = old_obj.employees;
        // if(this->week == NULL)
        //     this->week = new week;
        this->week = old_obj.week;
        this->name = old_obj.name;
        this->phone = old_obj.phone;
        this->address = old_obj.address;
    }
}


string Restaurant::get_name(){
    return this->name;
}

void Restaurant::set_name(string name){
    this->name = name;
}


void Restaurant::set_phone(string phone){
    this->phone = phone;
}


void Restaurant::set_address(string address){
    this->address = address;
}


void Restaurant::load_data(){

}


bool Restaurant::login(string id, string password){

}


void Restaurant::view_menu(){

}


void Restaurant::view_hours(){

}


void Restaurant::view_address(){
    cout << this->address << endl;
}


void Restaurant::view_phone(){
    cout << this->phone << endl;
}


void Restaurant::search_menu_by_price(){

}


void Restaurant::search_by_ingredients(){

}



// Only one of the following two prototypes should be used:
// selection is a dynamically allocated array of Pizza objects that are being ordered
// selection_size indicates the number of Pizza objects in the array
// num_ordered is a dynamically allocated array that indicates how many pizzas of each type were ordered
void Restaurant::place_order(Pizza* selection, int selection_size, int* num_ordered){

}


// you may also choose to use this prototype:
//void place_order(Pizza* selection);

void Restaurant::change_hours(){

}


void Restaurant::add_to_menu(){

}


void Restaurant::remove_from_menu(){

}


void Restaurant::view_orders(){

}


void Restaurant::remove_orders(){

}

