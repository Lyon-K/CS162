#include <iostream>
#include <fstream>
#include <string.h>
#include "restaurant.h"
using namespace std;

int main(int argc, char *argv[])
{
	//your main function lives here
	// declarations end
	ifstream fin("menu.txt");
	Pizza a, b, c, d;
	a.set_from_file(fin);
	a.display_pizza();
	b.set_from_file(fin);
	b.display_pizza();
	c.set_from_file(fin);
	c.display_pizza();
	d.set_from_file(fin);
	d.display_pizza();
	d = a;
	Pizza test = b;
	d.display_pizza();
	test.display_pizza();
	return 0;
}